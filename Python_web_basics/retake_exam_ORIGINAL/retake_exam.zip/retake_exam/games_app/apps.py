from django.apps import AppConfig


class GamesAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'retake_exam.games_app'
