from django.apps import AppConfig


class OnlineLibraryConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'retake_exam_11_aug_2021.online_library'
